<?php get_header(); ?>
<main class="wrap">

  <?php get_sidebar(); ?>
</main>

<main role="main">
      <br class="clearBoth">
      <div class="album padding-25top">

        <div class="container">
	        <div class="row padding-35 padding-15bottom padding-25top">
	        		<div class="col-md-6  titulo-primario">

	        			  <h1>Reembolsos corporativos de forma simples e rápida.</h1>
	        			  <h1><strong>Como deve ser.</strong></h1>

				          <p class="text-muted">
				          	Acabe com a dor de cabeça da gestão de despesas do dia a
							dia da sua empresa: pagamentos, reembolsos, compras on-line
							e gestão do fundo fixo. Controle seus gastos escaneando
							notas fiscais, acompanhando aprovações, visualizando
							relatórios e muito mais!
						 </p>

							<a class="btn btn-lg btn-primary" hole="button" href="#">Peça já sua proposta</a>
							<span>Responderemos <strong>em até 24h</strong>.</span>
	        		</div>

	        		<div class="col-md-6 large-header">
	        				 <img src="<?php bloginfo('template_directory'); ?>/img/large-Header_3d_3.png" class="img-fluid" alt="Responsive image">
	        		</div>
	        </div>
        </div>
   

       <div class="container">
	        <div class="row padding-35">

	        	    <div class="col-md-6">
	        	    	  <a href="#myModal" data-toggle="modal"><div class="bloco-azul"></div></a>
	        	    </div>

	        		<div class="col-md-6  titulo-secundario">
	        			  <div class="base-padding">
	        			  <h1>Assuma agora o  <br><strong>controle dos gastos</strong> <br>variáveis da sua empresa</h1>

				          <p class="text-muted">
				          	O BPP Corp é uma solução única para a 
							administração de gastos corporativos que conta
							com uma conta digital empresarial grátis, cartões
							VISA pré-pagos para controle total das despesas e
							um aplicativo sem custos adicionais para tornar
							seu controle financeiro mais simples e prático! 
						 </p>
						</div>
	        		</div>
	        		
	        </div>
        </div>


        <div class="container backg-blue">
	        <div class="row padding-35 padding-15bottom">
	        		<div class="col-md-6  titulo-trigesimo">
	        			  <h1>Organizar<br>
							reembolsos da sua<br>
							empresa nunca foi<br>
							tão rápido</h1>

				          <p class="text-muted">
				          	Utilizando BPP Corp, você tem controle total 
							sobre o budget de sua equipe podendo realizar 
							transferências instantâneas para os cartões 
							corporativos dos colaboradores, acompanhar 
							gastos, receber comprovantes e visualizar 
							relatórios que organizam seu reembolso. 
						 </p>

						 <a class="btn btn-lg btn-primary" hole="button" href="#">Peça já sua proposta</a>
	        		</div>

	        		 <div class="col-md-6">
	        	    	<div class="bpp-corp"></div>
	        	    </div>
	        </div>
        </div>


         <div class="container backg-cinza">
	        <div class="row padding-45 padding-35top">
	        	<div class="col-md-12 titulo-quarto">
	        		<h1>A plataforma que ajuda a <strong>reduzir os gastos</strong> do dia a dia</h1>
	        		<p>Simplifique a gestão das despesas, evitando a perda de tempo com comprovantes e<br>
                     planilhas, reduzindo custos e aumentando os resultados da sua empresa.</p>
                     <br class="clearBoth">
	        	</div>

	        	<div class="col-md-4 titulos-box">
	        		<img src="<?php bloginfo('template_directory'); ?>/img/icon1.png" class="img-fluid marginimg" alt="Responsive image" width="100">
	        		<h1>Mais rapidez na gestão <br> das suas despesas</h1>
	        		<p>Para que seu negócio cresça de maneira
					inteligente e rápida, substitua os processos
					demorados de reembolsos, aprovações,
					criação de relatórios e etc. por uma
					plataforma que te oferece tudo isso de forma
					rápida e digital. </p>
                     <br class="clearBoth">
	        	</div>

	        	<div class="col-md-4 titulos-box">
	        		<img src="<?php bloginfo('template_directory'); ?>/img/icon3.png" class="img-fluid marginimg" alt="Responsive image" width="100">
	        		<h1>Os relatórios que você<br> precisa em um único lugar</h1>
	        		<p>Encontre relatórios detalhados sobre as
					utilizações de cada cartão corporativo
					cadastrado em sua equipe. Confira o saldo de
					cada cartão, redistribua valores, faça
					transferências instantâneas e não perca tempo
					com formulários e planilhas.  </p>
                     <br class="clearBoth">
	        	</div>

	        	<div class="col-md-4 titulos-box">
	        		<img src="<?php bloginfo('template_directory'); ?>/img/icon4.png" class="img-fluid marginimg" alt="Responsive image" width="100">
	        		<h1>Organize todos os seus <br> comprovantes</h1>
	        		<p>Recebendo os comprovantes de gastos de seus
					colaboradores através da plataforma, você não
					precisa mais guardar comprovantes e notas
					fiscais em lugar nenhum. Os gastos podem ser
					classificados por tipo ou por projeto, da forma
					que você precisar. </p>
                     <br class="clearBoth">
	        	</div>

	        	<div class="col-md-4 titulos-box">
	        		<img src="<?php bloginfo('template_directory'); ?>/img/icon5.png" class="img-fluid marginimg" alt="Responsive image" width="100">
	        		<h1>Apresente suas despesas <br> com um só clique</h1>
	        		<p>Enviar seus comprovantes é mais simples do
					que você imagina. Basta que o colaborador tire
					uma foto do cupom fiscal com seu smartphone
					através do aplicativo BPP Card. O gestor das
					despesas pode aprovar ou reprovar aquele gasto
					através do App.</p>
                     <br class="clearBoth">
	        	</div>

	        	<div class="col-md-4 titulos-box">
	        		<img src="<?php bloginfo('template_directory'); ?>/img/icon6.png" class="img-fluid marginimg" alt="Responsive image" width="100">
	        		<h1>Controle seus gastos com <br> cartões pré-pagos VISA</h1>
	        		<p>Os cartões pré-pago BPP Corp são fáceis de
					controlar: o colaborador só gasta o que a
					empresa disponibiliza para compras online ou
					em lojas físicas. Conte com cartões VISA
					aceitos em mais de 30 milhões de
					estabelecimentos no mundo todo, incluindo
					sites e aplicativos! </p>
                     <br class="clearBoth">
	        	</div>

	        	<div class="col-md-4 titulos-box">
	        		<img src="<?php bloginfo('template_directory'); ?>/img/icon2.png" class="img-fluid marginimg" alt="Responsive image" width="100">
	        		<h1>Conta digital gratuita e <br> exclusiva para sua empresa</h1>
	        		<p>Oferecemos uma conta digital gratuita
					especialmente para gerenciar despesas.
					Transfira o saldo de sua conta para os cartões de
					maneira instantânea, sempre livre de taxas de
					manutenção ou de juros. </p>
                     <br class="clearBoth">
	        	</div>
	        </div>
	     </div>

        
         <div class="container">
	        <div class="row padding-35  padding-45top padding-15bottom padding0">

	        	    <div class="col-md-6">
	        	    	<ul class="logos-emp">
	        	    		<li class="burguer"></li>
	        	    		<li class="boticario"></li>
	        	    		<li class="cacau"></li>
	        	    		<li class="paguemais"></li>
	        	    	</ul>
	        	    </div>

	        		<div class="col-md-6  titulo-secundario">
	        			  <div class="base-padding">
	        			  <h1>Conheça quem já conta<br>
							com as <strong>vantagens<br>
							excluisivas</strong> do BPP Corp</h1>

				          <p class="text-muted">
				          	A empresas mais bem-sucedidas do<br>
							mundo, grandes e pequenas, confiam no<br>
							BPP Corp para reduzir custos com<br>
							organização dos gastos da suas empresas. 
						 </p>
						</div>
	        		</div>
	        		
	        </div>
        </div>

          <div class="container">
	        <div class="row padding-45 padding-35top">
	        	<div class="col-md-12 titulo-quinto">
	        		<h1>Compare e <strong>decida agora</strong> mesmo</h1>
	        		<p>Substitua o uso do dinheiro em espécie pelo BPP Corp e ganhe segurança e praticidade, evitando roubos e <br> perdas, tendo uma plataforma única para gerir suas despesas. </p>
                     <br class="clearBoth">
	        	</div>
	        </div>
	     </div>


	     <div class="container">
	        <div class="row padding-35">

	        	   <div class="col-md-6 titulo-sexto borderright">
	        			 <div class="base-padding">
	        			 	<img src="<?php bloginfo('template_directory'); ?>/img/group_din.png" class="img-fluid marginimg" alt="Responsive image" width="46">
		        			  <h1 class="ch1">Dinheiro em papel</h1>

					          <p class="text-muted">
					          	Saque de dinheiro em papel para as despesas
								Várias notas fiscais em papel
								Diversas planilhas de gestão
								Problemas de contabilização dos gastos
								Não tem segurança
							 </p>
						</div>
	        		</div>
	        		<div class="col-md-6  titulo-sexto">
	        			 <div class="base-padding">

	        			 	<img src="<?php bloginfo('template_directory'); ?>/img/group.png" class="img-fluid marginimg" alt="Responsive image" width="30">
		        			  <h1>BPP Corp</h1>

					          <p class="blue-p">
					          	Faça pagamentos com o BPP Corp sem precisar tirar dinheiro
								Prestação de contas sem papel, via app
								Relatórios completos em um único lugar
								Controle dos gastos com cartões pré-pago
								Segurança total do seu dinheiro
							 </p>
						</div>
	        		</div>
	        		
	        </div>
        </div>


         <div class="container backg-blue-img padding-35top">
	        <div class="row padding-35 padding-15bottom">
	        		<div class="col-md-12  titulo-setimo">
	        			  <h1>A sua gestão financeira nunca foi tão fácil. </h1>

				          <p>
				          	Conte com as soluções do BPP Corp e facilite o controle dos gastos da sua empresa agora mesmo.
						 </p>

						 <a class="btn btn-lg btn-primary" hole="button" href="#">Peça já sua proposta</a>
                         <br/>
						 <span>Proposta grátis e sem compromisso.</span>
	        		</div>

	        </div>
        </div>

        <div class="container ultimos padding-45top">
	        <div class="row padding-35">
	        		<div class="col-md-12 ">
	        			  <h1>Últimos posts</h1>
	        		</div>
	        </div>
        </div>


        <div class="container">

          <div class="row padding-posts">

                <?php if ( have_posts() ) : while ( have_posts() ) : the_post(); ?>
				       <div class="col-md-4 margin30">
			              <div class="card mb-4 box-shadow">

			                 <?php  the_post_thumbnail( 'large' ); ?>

			                  <!--<p class="card-text"><?php //the_excerpt(); ?></p>-->
			                  <div class="d-flex justify-content-between align-items-center link-bt">
			                    <a class="btn" href="<?php the_permalink(); ?>" title="<?php the_title_attribute(); ?>"><?php the_title(); ?></a>
			                  </div>
			              </div>
			           </div>
				<?php endwhile; else : ?>
				      <article>
				        <p>Sorry, no posts were found!</p>
				      </article>
				<?php endif; ?>

              </div>
            </div>

          </div>
        </div>


         <div class="container fim padding-35top padding-15bottom">
	        <div class="row padding-35">
	        		<div class="col-md-6 ">
	        			  <h1>Esta página foi útil?</h1>
	        		</div>

	        		<div class="col-md-6 ">
	        			  <img class="emoticons" src="<?php bloginfo('template_directory'); ?>/img/motions.png" class="img-fluid marginimg" alt="Responsive image">
	        		</div>
	        </div>
        </div>

        <!-- Modal HTML -->
		    <div id="myModal" class="modal fade">
		        <div class="modal-dialog">
		            <div class="modal-content">
		                <div class="modal-header">
		                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
		                </div>
		                <div class="modal-body">
		                    <iframe id="promoVideo" width="100%" height="315" src="//www.youtube.com/embed/4oeVCWTyUpY" frameborder="0" allowfullscreen></iframe>
		                </div>
		            </div>
		        </div>
		    </div>
		</div>     

      </div>

 </main>
<?php get_footer(); ?>